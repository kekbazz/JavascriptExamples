<html>
  <head>
    <title></title>
    <script src="quotegen.js"></script>
    <style>
      body{
        padding:20px;
        text-align: center;
        color: purple
      }
    </style>
  </head>
  
  <body bgcolor="#fff">
    <!-- Display the countdown timer in an element -->
    <h2>Words of encouragement</h2>
    <p id="randomQuotes"></p>
  </body>
</html>
