//QUOTE GENERATOR
var quotes = [
  "God won't help you, he already gave you the power to do that.", 
  
  "Civilize the mind, make savage the body.", 
  
  "I never changed, I just woke up...",
  
  "Yes they came back because your energy is amazing, they also came back because they want more free access to it.",
  
  "Sometimes we're tested not to show our weaknesses, but to discover our strengths",
  
  "You are what you eat, you become how you think",
  
  
  "The only power which can illuminate you is your own mind! No other mind can lighten you if your mind insists to remain in the darkness! The fate of your fate is within you! -Mehmet Murat ildan",
  
  "Conspiracy theories are ways for someone to understand what is going on in the world and try to restore some sense of control in themselves.",
  
  "Truth will always be fabricated so that the lies can be hidden within. -Anthony T. Hincks",
  
];

// Update the count down every 1 second
var x1 = setInterval(function(){

  var randomQuotes = quotes[Math.floor(Math.random() * Math.floor(9))];

  document.getElementById("randomQuotes").innerHTML = "<h1>"+randomQuotes+"</h1>";

}, 6000); //Every 5 seconds

